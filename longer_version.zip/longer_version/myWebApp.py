from flask import Flask, request, render_template, jsonify
from datetime import datetime

# setup Flask app
app = Flask(__name__)


# Ensure responses aren't cached on your browser.
# Useful to see the changes you have made to your front end.
# You can delete this block once the project is finished.
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# When someone accesses "/" returns the index.html file in the teamplate folder
@app.route("/")
def home():
    return render_template("index.html")


# Saves new post to the posts.txt file in your root folder
@app.route("/save", methods=["POST"])
def save():
    with open("posts.txt", mode="a") as f:
        f.write("-" * 15)
        f.write(str(datetime.now())[:19] + "\n")
        f.write(request.form["text"] + "\n")
    return ""


# Loads all the posts from the posts.txt file
@app.route("/load", methods=["POST"])
def load():
    with open("posts.txt") as f:
        data = enumerate(f.read().split("-" * 15)[::-1])
        response = {k: [v[:19], v[19:]] for k, v in data}
    return jsonify(response)


# Run the program
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3126, threaded=True, debug=False)
