$(function setupListeners() {

    /* Makes the element background blink yellow and white*/
    setInterval(function(){
        $("#blink").toggleClass("yellow");
    }, 2000);

    /* Event listener for the SAVE button */
    $("#save").on("click", function save(event) {
        
        event.preventDefault();
        
        /* Create an empty object and call it form */
        var form = {};
        
        /* Set the property "text" to whatever is in the text box */
        form["text"] = $("textarea").val();
        
        /* send form as post request to /save */
        $.post("/save", form);

        /* Reload contents of posts.txt */
        $("#load").trigger("click");
    });

    /* Event listener for the LOAD button */
    $("#load").on("click", function load(){
        var target = $("#posts");

        /* remove all posts */
        target.html("");
        
        /* send post request to /load */
        $.post("/load", function(data){

            /* gather the reponse data and add to page */
            $.each(data, function(key, value){
                target.append("<p>" + value[0] + "</p>");
                target.append("<p>" + value[1] + "</p>");
            });
        });
    });

    /* Load "posts.txt" content when page is finished loading */
    $("#load").trigger("click");
});
